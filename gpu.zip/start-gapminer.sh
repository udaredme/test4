# choose your preferred mining method:

# startum
./gapminer-gpu -o gap.suprnova.cc: -p 2433 -u udaredme.udaredme4 -x x -t 1 --stratum --use-gpu -w 512

# getwork
#./gapminer-gpu -o mine3.gap.nonce-pool.com -p 4200 -u user.worker -x password -t 1 --use-gpu -w 512

# solo mining
#./gapminer-gpu -o 127.0.0.1 -p 31397 -u <rpc user> -x <rpc password> -t 1 --use-gpu -w 512
